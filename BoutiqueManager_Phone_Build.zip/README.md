# Boutique Manager - Android MVP source

## What this starter app includes
- Native Android application (Kotlin)
- Offline local SQLite storage
- Shop name setting
- Dress inventory (code, name, size, color, rental price)
- Booking records (customer, phone, dress, date range, price, deposit)
- Prevents overlapping bookings for the same dress
- Booking list and cancellation

## Build an APK
1. Install Android Studio (recent stable version) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in `app/build/outputs/apk/debug/`.

## Important MVP limitations
- This is a starter prototype, not a production-ready commercial SaaS release.
- Data is stored only on the phone. Uninstalling the app or losing the phone can lose data.
- No cloud backup/sync, user login, multi-shop tenant isolation, subscription billing, payment gateway, notifications, or Play Store signing yet.
- Dates are entered as YYYY-MM-DD.
- Dress photos and custom logo image upload are not included in this first source scaffold.
- Before commercial launch, add encrypted backup/export, authentication, tenant isolation, subscription status handling, privacy policy, and thorough testing.

## Technical details
- Package: `com.boutiquemanager`
- Min Android: 6.0 (API 23)
- Target SDK: 35
- Database: SQLite
