package com.boutiquemanager

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.text.SimpleDateFormat
import java.util.Locale

data class Dress(val id: Long, val code: String, val name: String, val size: String, val color: String, val price: Double)
data class Booking(val id: Long, val customer: String, val phone: String, val dressId: Long, val dressName: String, val start: String, val end: String, val price: Double, val deposit: Double, val status: String)

class StoreDb(context: Activity) : SQLiteOpenHelper(context, "boutique_manager.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE dresses(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, size TEXT, color TEXT, price REAL)""")
        db.execSQL("""CREATE TABLE bookings(id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT, phone TEXT, dress_id INTEGER, start_date TEXT, end_date TEXT, price REAL, deposit REAL, status TEXT)""")
        db.execSQL("""CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)""")
        db.execSQL("INSERT INTO settings(key,value) VALUES('shop_name','متجري')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun shopName(): String {
        val c = readableDatabase.rawQuery("SELECT value FROM settings WHERE key='shop_name'", null)
        val v = if(c.moveToFirst()) c.getString(0) else "متجري"; c.close(); return v
    }
    fun setShopName(name: String) {
        val cv=ContentValues().apply { put("key","shop_name"); put("value",name) }
        writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun addDress(code:String,name:String,size:String,color:String,price:Double) {
        val cv=ContentValues().apply { put("code",code);put("name",name);put("size",size);put("color",color);put("price",price) }
        writableDatabase.insert("dresses",null,cv)
    }
    fun dresses(): List<Dress> {
        val out= mutableListOf<Dress>(); val c=readableDatabase.rawQuery("SELECT id,code,name,size,color,price FROM dresses ORDER BY id DESC",null)
        while(c.moveToNext()) out.add(Dress(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getDouble(5)))
        c.close(); return out
    }
    fun addBooking(customer:String,phone:String,dressId:Long,start:String,end:String,price:Double,deposit:Double): Boolean {
        val conflict=readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM bookings WHERE dress_id=? AND status!='ملغي' AND start_date<=? AND end_date>=?",
            arrayOf(dressId.toString(),end,start))
        conflict.moveToFirst(); val busy=conflict.getInt(0)>0; conflict.close()
        if(busy) return false
        val cv=ContentValues().apply {
            put("customer",customer);put("phone",phone);put("dress_id",dressId)
            put("start_date",start);put("end_date",end);put("price",price);put("deposit",deposit);put("status","محجوز")
        }
        writableDatabase.insert("bookings",null,cv); return true
    }
    fun bookings(): List<Booking> {
        val out= mutableListOf<Booking>()
        val c=readableDatabase.rawQuery("""SELECT b.id,b.customer,b.phone,b.dress_id,d.name,b.start_date,b.end_date,b.price,b.deposit,b.status
            FROM bookings b LEFT JOIN dresses d ON d.id=b.dress_id ORDER BY b.id DESC""",null)
        while(c.moveToNext()) out.add(Booking(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getString(4) ?: "فستان",c.getString(5),c.getString(6),c.getDouble(7),c.getDouble(8),c.getString(9)))
        c.close(); return out
    }
    fun cancelBooking(id:Long) { writableDatabase.execSQL("UPDATE bookings SET status='ملغي' WHERE id=?", arrayOf(id)) }
    fun deleteDress(id:Long) { writableDatabase.delete("dresses","id=?", arrayOf(id.toString())) }
    fun countBookings() = bookings().count { it.status=="محجوز" }
}

class MainActivity : Activity() {
    private lateinit var db: StoreDb
    private lateinit var root: LinearLayout
    private val purple = Color.rgb(41,36,61)
    private val gold = Color.rgb(211,181,112)
    private val ink = Color.rgb(48,42,65)
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db=StoreDb(this)
        showHome()
    }
    private fun setup(title:String) {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18)); setBackgroundColor(Color.rgb(250,248,252)) }
        val header=TextView(this).apply {
            text="👗  Boutique Manager\n$title"
            textSize=22f; setTextColor(Color.WHITE); setPadding(dp(16),dp(18),dp(16),dp(18)); setBackgroundColor(purple)
        }
        root.addView(header, LinearLayout.LayoutParams(-1,-2))
        val scroll=ScrollView(this)
        val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,dp(12),0,dp(20)) }
        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        currentContent=content
    }
    private lateinit var currentContent: LinearLayout
    private fun label(text:String, size:Float=16f) {
        currentContent.addView(TextView(this).apply { this.text=text; textSize=size; setTextColor(ink); setPadding(0,dp(10),0,dp(6)) })
    }
    private fun button(text:String, action:()->Unit) {
        val b=Button(this).apply { this.text=text; textSize=15f; isAllCaps=false; setTextColor(Color.WHITE); backgroundTintList=android.content.res.ColorStateList.valueOf(purple); setOnClickListener{action()} }
        val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(5),0,dp(5)); currentContent.addView(b,p)
    }
    private fun field(hint:String, type:Int=InputType.TYPE_CLASS_TEXT): EditText {
        val e=EditText(this).apply { this.hint=hint; inputType=type; textSize=16f; setSingleLine(true) }
        currentContent.addView(e,LinearLayout.LayoutParams(-1,-2)); return e
    }
    private fun showHome() {
        setup("إدارة المحل")
        label("مرحباً بك في ${db.shopName()}",20f)
        label("الحجوزات النشطة: ${db.countBookings()}     |     عدد الفساتين: ${db.dresses().size}")
        button("＋ تسجيل حجز جديد"){ showNewBooking() }
        button("👗 إدارة الفساتين"){ showDresses() }
        button("📋 سجل الحجوزات"){ showBookings() }
        button("⚙ إعدادات المحل"){ showSettings() }
        label("يتم حفظ البيانات محلياً على هذا الهاتف، ويمكن استخدام الوظائف الأساسية دون إنترنت.",13f)
    }
    private fun showDresses() {
        setup("إدارة الفساتين")
        button("＋ إضافة فستان"){ addDressDialog() }
        val list=db.dresses()
        if(list.isEmpty()) label("لا توجد فساتين. أضف أول فستان للبدء.")
        list.forEach { d ->
            label("${d.code} — ${d.name}\nالمقاس: ${d.size} | اللون: ${d.color} | الإيجار: ${d.price}")
            button("حذف ${d.code}") {
                AlertDialog.Builder(this).setMessage("حذف الفستان؟").setNegativeButton("رجوع",null).setPositiveButton("حذف"){_,_->db.deleteDress(d.id);showDresses()}.show()
            }
        }
        button("العودة للرئيسية"){showHome()}
    }
    private fun addDressDialog() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),0,dp(20),0) }
        fun add(h:String):EditText { val e=EditText(this).apply{hint=h};box.addView(e);return e }
        val code=add("رقم الفستان مثل 001"); val name=add("اسم الفستان"); val size=add("المقاس"); val color=add("اللون"); val price=add("سعر الإيجار")
        AlertDialog.Builder(this).setTitle("إضافة فستان").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
            try { if(code.text.isBlank()||name.text.isBlank()) throw Exception()
                db.addDress(code.text.toString(),name.text.toString(),size.text.toString(),color.text.toString(),price.text.toString().toDoubleOrNull()?:0.0);showDresses()
            } catch(_:Exception){toast("تحقق من البيانات أو رقم الفستان مكرر")}
        }.show()
    }
    private fun showNewBooking() {
        setup("حجز جديد")
        val customer=field("اسم الزبونة")
        val phone=field("رقم الهاتف",InputType.TYPE_CLASS_PHONE)
        val ds=db.dresses()
        if(ds.isEmpty()){label("أضف الفساتين أولاً قبل تسجيل الحجوزات.");button("إدارة الفساتين"){showDresses()};button("الرئيسية"){showHome()};return}
        label("اختيار الفستان")
        val spinner=Spinner(this)
        val adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,ds.map{"${it.code} - ${it.name} (${it.price})"})
        spinner.adapter=adapter;currentContent.addView(spinner)
        val start=field("تاريخ الاستلام YYYY-MM-DD")
        val end=field("تاريخ الإرجاع YYYY-MM-DD")
        val price=field("سعر الإيجار",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val deposit=field("العربون",InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        button("حفظ الحجز") {
            val s=start.text.toString().trim(); val e=end.text.toString().trim()
            if(customer.text.isBlank()||phone.text.isBlank()||s.isBlank()||e.isBlank()){toast("أكمل البيانات المطلوبة");return@button}
            if(!validDate(s)||!validDate(e)||s>e){toast("اكتب التاريخ بصيغة YYYY-MM-DD وتحقق من التواريخ");return@button}
            val d=ds[spinner.selectedItemPosition]
            val p=price.text.toString().toDoubleOrNull()?:d.price
            val dep=deposit.text.toString().toDoubleOrNull()?:0.0
            if(dep<0||p<0||dep>p){toast("تحقق من السعر والعربون");return@button}
            if(db.addBooking(customer.text.toString(),phone.text.toString(),d.id,s,e,p,dep)) {toast("تم حفظ الحجز");showBookings()}
            else toast("الفستان محجوز في هذه الفترة")
        }
        button("الرئيسية"){showHome()}
    }
    private fun showBookings() {
        setup("سجل الحجوزات")
        val list=db.bookings()
        if(list.isEmpty()) label("لا توجد حجوزات مسجلة.")
        list.forEach { b ->
            label("${b.customer} — ${b.dressName}\n${b.start} إلى ${b.end}\nالهاتف: ${b.phone}\nالإيجار: ${b.price} | العربون: ${b.deposit} | المتبقي: ${b.price-b.deposit}\nالحالة: ${b.status}")
            if(b.status=="محجوز") button("إلغاء هذا الحجز"){AlertDialog.Builder(this).setMessage("إلغاء الحجز؟").setNegativeButton("لا",null).setPositiveButton("نعم"){_,_->db.cancelBooking(b.id);showBookings()}.show()}
        }
        button("حجز جديد"){showNewBooking()}
        button("الرئيسية"){showHome()}
    }
    private fun showSettings() {
        setup("إعدادات المحل")
        val name=field("اسم المحل")
        name.setText(db.shopName())
        button("حفظ اسم المحل"){if(name.text.isNotBlank()){db.setShopName(name.text.toString());toast("تم الحفظ");showHome()}}
        label("هذه النسخة الأولية تحفظ بيانات المحل على الجهاز فقط. أضف النسخ الاحتياطي والمزامنة قبل الاستخدام التجاري.")
        button("الرئيسية"){showHome()}
    }
    private fun validDate(s:String):Boolean = try {
        val f=SimpleDateFormat("yyyy-MM-dd",Locale.US); f.isLenient=false; f.parse(s)!=null
    } catch(_:Exception){false}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}
